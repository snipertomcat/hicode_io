		<a href="<?php echo $homepageurl;?>" target="_blank"><div class="call_section" style="background:url(<?php echo $homepagebanner;?>)center center no-repeat fixed;@include background-size(cover);
	min-height: 400px;
	padding: 10% 0;">
			<div class="container clearfix">
				<!-- <div class="col-lg-5 col-md-6 float-right wow" data-wow-offset="250">
					<div class="block-reveal">
						<div class="block-vertical"></div>
						<div class="box_1">
							<h3>Enjoy a great students community</h3>
							<p>Ius cu tamquam persequeris, eu veniam apeirian platonem qui, id aliquip voluptatibus pri. Ei mea primis ornatus disputationi. Menandri erroribus cu per, duo solet congue ut. </p>
							<a href="#0" class="btn_1 rounded">Read more</a>
						</div>
					</div>
				</div> -->
			</div>
		</div></a>
		<!--/call_section-->