		<div class="container margin_30_95">
			<div class="main_title_2">
				<span><em></em></span>
				<h2>Categories Courses</h2>
				<!--<p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p> -->
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Graphics" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="graphic_design.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>15 Programmes</small> -->
								<h3>Graphics & Design</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Digital+Marketing" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="digital_marketing.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Digital Marketing</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Writing" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="writing_translation.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;"> 
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Writing & Translation</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Video" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="video_animation.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Video & Animation</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Music" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="music.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Music & Audio</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Tech" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="programming_tech.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Programming & Tech</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Business" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="business.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Business</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Lifestyle" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="lifestyle.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Lifestyle</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
				<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="fcourses-list.php?fskyd=Trending" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="trending.jpg" class="img-fluid" alt="" style="width: 400px;height: 200px;">
							<div class="info">
								<!-- <small><i class="ti-layers"></i>23 Programmes</small> -->
								<h3>Trending</h3>
							</div>
						</figure>
					</a>
				</div>
				<!-- /grid_item -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->